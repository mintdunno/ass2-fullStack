const express = require("express");
const app = express();
const port = 3000;
const bcrypt = require("bcrypt");
const fileUpload = require("express-fileupload");

app.set("view engine", "ejs");
app.use(express.static("public"));
app.use(fileUpload());

// Process Post form
app.use(express.urlencoded({ extended: true }));
