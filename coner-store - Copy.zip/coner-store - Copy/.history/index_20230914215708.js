const express = require("express");
const app = express();
const port = 3000;
const bcrypt = require("bcrypt");
const fileUpload = require("express-fileupload");
const { schema } = require("./models/schema");
app.set("view engine", "ejs");
app.use(express.static("public"));
app.use(fileUpload());
// Process Post form
app.use(express.urlencoded({ extended: true }));

const schema = require("./model/schema");
const Customer = schema.Customer;
const Vendor = schema.Vendor;
const Product = schema.Product;

// Route for login page. Users have to log in to use the website
app.get("/", (req, res) => {
  res.render("login-page");
});

app.listen(port, () => {
  console.log(`Server started on port ${port}`);
});
