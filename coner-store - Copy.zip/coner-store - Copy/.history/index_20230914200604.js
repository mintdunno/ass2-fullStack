const express = require("express");
const app = express();
const port = 3000;
const bcrypt = require("bcrypt");
const fileUpload = require("express-fileupload");
const { config } = require("process");

app.set("view engine", "ejs");
app.use(express.static("public"));
app.use(fileUpload());

// Process Post form
app.use(express.urlencoded({ extended: true }));
// Connect to mongoose
const mongoose = require("./config/mongoose");

// Route for login page. Users have to log in to use the website
app.get("/", (req, res) => {
  res.render("login-page");
});

app.listen(port, () => {
  console.log(`Server started on port ${port}`);
});
