const mongoose = require("mongoose");
const Schema = mongoose.Schema;
mongoose
  .connect(
    "mongodb+srv://mint:mint@corner-store.cbiyacl.mongodb.net/Store?retryWrites=true&w=majority"
  )
  .then(() => console.log("Connected to MongoDB Atlas"))
  .catch((error) => console.log(error.message));

const customerSchema = new Schema(
  {
    fullname: String,

    email: {
      type: String,
      required: true,
      minLength: 5,
    },

    phone: {
      type: Number,
      require: true,
    },

    address: String,
    username: {
      type: String,
      required: true,
      unique: true,
      minLength: 8,
      maxLength: 15,
      match: /^[a-zA-Z0-9]+$/,
    },

    password: {
      type: String,
      required: true,
      minLength: 8,
      match: /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*]).*$/,
    },

    profilePicture: {
      data: Buffer,
      mimeType: String,
    },
  },
  { timestamps: true }
);

const vendorSchema = new Schema(
  {
    fullName: String,

    bName: String,

    email: {
      type: String,
      required: true,
      minLength: 5,
    },

    phone: {
      type: Number,
      require: true,
    },

    address: String,
    username: {
      type: String,
      required: true,
      unique: true,
      minLength: 8,
      maxLength: 15,
      match: /^[a-zA-Z0-9]+$/,
    },

    password: {
      type: String,
      required: true,
      minLength: 8,
      match: /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*]).*$/,
    },

    profilePicture: {
      data: Buffer,
      mimeType: String,
    },
  },
  { timestamps: true }
);

const productSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    minLength: 10,
    maxLength: 20,
  },
  price: {
    type: Number,
    required: true,
    min: 0,
  },
  image: {
    data: Buffer,
    mimeType: String,
  },
  description: {
    type: String,
    maxLength: 500,
  },
  amount: {
    type: Number,
    required: true,
    min: 0,
  },
  category: {
    type: String,
    required: true,
    enum: [
      "Beauty Cosmetic",
      "Fashion",
      "Sports & Outdoors",
      "Health & Household",
      "Home & Kitchen",
      "Electronics",
    ],
  },
  vendorUsername: {
    type: String,
    required: true,
  },
});

// Create Customer model
const Customer = mongoose.model("Customer", customerSchema);
// Create Product model
const Product = mongoose.model("Product", productSchema);
//Create Vendor model
const Vendor = mongoose.model("Vendor", vendorSchema);
module.exports = { Customer, Vendor, Product };
