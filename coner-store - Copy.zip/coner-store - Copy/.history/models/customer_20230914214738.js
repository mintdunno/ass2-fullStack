const mongoose = require("mongoose");
const Schema = mongoose.Schema;
mongoose
  .connect(
    "mongodb+srv://mint:mint@corner-store.cbiyacl.mongodb.net/Store?retryWrites=true&w=majority"
  )
  .then(() => console.log("Connected to MongoDB Atlas"))
  .catch((error) => console.log(error.message));

const customerSchema = new Schema(
  {
    fullname: String,

    email: {
      type: String,
      required: true,
      minLength: 5,
    },

    phone: {
      type: Number,
      require: true,
    },

    address: String,
    username: {
      type: String,
      required: true,
      unique: true,
      minLength: 8,
      maxLength: 15,
      match: /^[a-zA-Z0-9]+$/,
    },

    password: {
      type: String,
      required: true,
      minLength: 8,
      match: /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*]).*$/,
    },

    profilePicture: {
      data: Buffer,
      mimeType: String,
    },
  },
  { timestamps: true }
);

// Create Customer model
const Customer = mongoose.model("Customer", customerSchema);
module.exports = Customer;
