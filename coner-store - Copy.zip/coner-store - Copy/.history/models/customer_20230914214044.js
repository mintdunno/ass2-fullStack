const express = require("express");
// Connect to mongoose
// Access config to see mongoose link
const mongoose = require("../config/mongoose");
const customerSchema = new Schema(
  {
    fullname: String,

    email: {
      type: String,
      required: true,
      minLength: 5,
    },

    phone: {
      type: Number,
      require: true,
    },

    address: String,
    username: {
      type: String,
      required: true,
      unique: true,
      minLength: 8,
      maxLength: 15,
      match: /^[a-zA-Z0-9]+$/,
    },

    password: {
      type: String,
      required: true,
      minLength: 8,
      match: /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*]).*$/,
    },

    profilePicture: {
      data: Buffer,
      mimeType: String,
    },
  },
  { timestamps: true }
);

// Create Customer model
const Customer = mongoose.model("Customer", customerSchema);
module.exports = Customer;
