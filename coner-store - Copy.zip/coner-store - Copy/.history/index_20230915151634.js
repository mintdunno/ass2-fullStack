const express = require("express");
const app = express();
const port = 3000;
const bcrypt = require("bcryptjs");
const fileUpload = require("express-fileupload");
const schema = require("./models/schema");
const Customer = schema.Customer;
const Vendor = schema.Vendor;
const Product = schema.Product;

app.set("view engine", "ejs");
app.use(express.static("public"));
app.use(fileUpload());
// Process Post form
app.use(express.urlencoded({ extended: true }));

schema.Vendor;
// Route for login page. Users have to log in to use the website
app.get("/", (req, res) => {
  res.render("login-page");
});

app.get("/vendor/register", (req, res) => {
  res.send("This vendor page");
});

app.post("/vendor/register", async (req, res) => {
  let errors = [];
  try {
    const {
      fullName,
      bName,
      email,
      phone,
      address,
      username,
      password,
      profilePicture,
    } = req.body;
    // Check if username of vendor is already taken
    const existedVendor = await Vendor.findOne({ username });
    if (existedVendor) {
      errors.push({ msg: "Vendor's Username existed" });
      return res.render("register", errors);
    }

    // Create Hash password
    const hashedPassword = await bcrypt.hash(password, 10);
    const vendor = new Vendor({
      fullName,
      bName,
      email,
      phone,
      address,
      username,
      password: hashedPassword,
      profilePicture: {
        data: req.files.profilePicture.data,
        mimeType: req.files.profilePicture.mimetype,
      },
    });
    await vendor.save();

    //redirected to login page
    res.send("This is login page");
  } catch (error) {
    console.error(error.message);
    res.status(500).json({ error: "Server error" });
  }
});

app.get("/", (req, res) => {
  res.send("Login page");
});

// Login part section is here

app.post("/", async (req, res) => {
  try {
    const { username, password, role } = req.body;

    //Check the customer Database
    if (role == "Customer") {
      const customer = await Customer.findOne({ username });
      // IF account doesn't exist
      if (!customer) {
        return res.render("login-page", {
          errorMsg: "Invalid username or password",
        });
      }
      // Compare both password by using harspass
      const passwordMatch = await bcrypt.compare(password, customer.password);

      // Redirect to login page if password is wrong
      if (!passwordMatch) {
        return res.render("login-page", {
          errorMsg: "Invalid username or password",
        });
      }

      //Access homepage by ID
      const id = customer._id;
      res.redirect(`/customer/homepage/${id}`);
    }

    //Check the Vendor Database
    if (role == "Vendor") {
      const vendor = await Vendor.findOne({ username });
      // IF account doesn't exist
      if (!vendor) {
        return res.render("login-page", {
          errorMsg: "Invalid username or password",
        });
      }
      // Compare both password by using harspass
      const passwordMatch = await bcrypt.compare(password, vendor.password);

      // Redirect to login page if password is wrong
      if (!passwordMatch) {
        return res.render("login-page", {
          errorMsg: "Invalid username or password",
        });
      }

      //Access homepage by ID
      const id = vendor._id;
      res.redirect(`/vendor/homepage/${vendor._id}`);
    }

    //check Shipper Database
    // Shipper now doesn't database
    if (role == "Shipper") {
      const shipper = await Shipper.findOne({ username });
      // IF account doesn't exist
      if (!shipper) {
        return res.render("login-page", {
          errorMsg: "Invalid username or password",
        });
      }
      // Compare both password by using harspass
      const passwordMatch = await bcrypt.compare(password, shipper.password);

      // Redirect to login page if password is wrong
      if (!passwordMatch) {
        return res.render("login-page", {
          errorMsg: "Invalid username or password",
        });
      }

      //Access homepage by ID
      const id = shipper._id;
      res.redirect(`/shipper/homepage/${id}#product-page`);
    }
  } catch (error) {
    console.error(error);
    res.status(501).json({ error: "Server error" });
  }
});

// Vender Route part
// Route for Vendor homepage
app.get("/vendor/homepage/:id", (req, res) => {
  const id = req.params.id;
  Vendor.findById(id)
    .then((vendor) => {
      res.render("vendor-homepage", { vendor });
    })
    .catch((error) => res.send(error));
});

app.get("/vendor/addproduct/:id", (req, res) => {
  const id = req.params.id;
  Vendor.findById(id)
    .then((vendor) => {
      res.render("addProduct", { vendor });
    })
    .catch((error) => res.send(error));
});

app.post("/vendor/addproduct/:id", (req, res) => {
  const id = req.params.id;
  Vendor.findById(id)
    .then((vendor) => {
      res.render("addProduct", { vendor });
    })
    .catch((error) => res.send(error));
});

app.listen(port, () => {
  console.log(`Server started on port ${port}`);
});
