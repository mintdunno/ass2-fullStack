const express = require("express");
const app = express();
const port = 3000;
const bcrypt = require("bcrypt");
const fileUpload = require("express-fileupload");
app.set("view engine", "ejs");
app.use(express.static("public"));
app.use(fileUpload());
// Process Post form
app.use(express.urlencoded({ extended: true }));
// Connect to mongoose
// Access config to see mongoose link
const mongoose = require("./config/mongoose");

const Customer = require("./models/customer");

// Route for login page. Users have to log in to use the website
app.get("/", (req, res) => {
  res.render("login-page");
});

// Route for handling Customer registration form submission
// Route for handling Customer registration form submission
app.post("/customer/register", async (req, res) => {
  try {
    const { username, password, profilePicture, email, terms, name, address } =
      req.body;

    // Check if username is already taken
    const existingUser = await User.findOne({ username });
    if (existingUser) {
      return res.status(409).json({
        error: "Username is already taken",
        message:
          "You should go back to the register page and sign up with a different Username",
      });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create new Customer document and save to database
    const newCustomer = new Customer({
      username,
      password: hashedPassword,
      profilePicture: {
        data: req.files.profilePicture.data,
        mimeType: req.files.profilePicture.mimetype,
      },
      email,
      terms,
      name,
      address,
    });
    await newCustomer.save();

    // Redirect to Customer homepage
    const id = newCustomer._id;
    res.redirect(`/customer/homepage/${id}`);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Server error" });
  }
});

app.listen(port, () => {
  console.log(`Server started on port ${port}`);
});
