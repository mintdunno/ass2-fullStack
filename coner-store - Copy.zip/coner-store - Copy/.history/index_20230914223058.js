const express = require("express");
const app = express();
const port = 3000;
const bcrypt = require("bcrypt");
const fileUpload = require("express-fileupload");
const schema = require("./models/schema");
const Customer = schema.Customer;
const Vendor = schema.Vendor;
const Product = schema.Product;

app.set("view engine", "ejs");
app.use(express.static("public"));
app.use(fileUpload());
// Process Post form
app.use(express.urlencoded({ extended: true }));

schema.Vendor;
// Route for login page. Users have to log in to use the website
app.get("/", (req, res) => {
  res.render("login-page");
});

app.get("/vendor/register", (req, res) => {
  res.send("This vender page");
});

app.post("/vendor/register", async (req, res) => {
  try {
    const {
      fullName,
      bName,
      email,
      phone,
      address,
      username,
      password,
      profilePicture,
    } = req.body;
    // Check if username of vendor is already taken
    const existedVendor = await Vendor.findOne({ username });
    if (existingUser) {
      return res.redirect(`/vendor/register`);
    }

    // Create Hash password
    const hashedPassword = await bcrypt.hash(password, 10);
    const vendor = new Vendor({
      fullName,
      bName,
      email,
      phone,
      address,
      password: hashedPassword,
      profilePicture: {
        data: req.files.profilePicture.data,
        mimeType: req.files.profilePicture.mimetype,
      },
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Server error" });
  }
});

app.listen(port, () => {
  console.log(`Server started on port ${port}`);
});
